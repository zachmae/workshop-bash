/*
** EPITECH PROJECT, 2022
** workshop_bash
** File description:
** my_do_op
*/

#ifndef MY_DO_OP_H_
    #define MY_DO_OP_H_

    int do_op(char *n1, char *op, char *n2);
    int my_add(int n1, int n2);
    int my_sub(int n1, int n2);
    int my_mul(int n1, int n2);
    int my_div(int n1, int n2);
    int my_mod(int n1, int n2);

#endif /* !MY_DO_OP_H_ */
